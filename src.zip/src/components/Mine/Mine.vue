<template>
  <div>
    
  </div>
</template>

<script>
export default {
  created() {
    window.location.href = "http://www.itdks.com/mobile/user"
  }
}
</script>

<style>

</style>
